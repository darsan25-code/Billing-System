# Billing System – Sree Vel Murugan Hardware and Tiles

Desktop-first billing system for **Sree Vel Murugan Hardware and Tiles**.

## Project Structure

```
billing-system/
├── index.html                        ← App entry point
└── src/
    ├── app.js                        ← Bootstrap: mounts components & starts router
    ├── styles/
    │   └── main.css                  ← Global desktop layout styles
    │
    ├── pages/
    │   ├── Dashboard/Dashboard.js    ← Dashboard (placeholder)
    │   ├── Billing/Billing.js        ← Billing (placeholder)
    │   ├── Products/Products.js      ← Products catalogue (placeholder)
    │   ├── Customers/Customers.js    ← Customers (placeholder)
    │   ├── Reports/Reports.js        ← Reports (placeholder)
    │   └── Settings/Settings.js      ← Settings (placeholder)
    │
    ├── components/
    │   ├── Sidebar/Sidebar.js        ← Left nav sidebar
    │   ├── Navbar/Navbar.js          ← Top bar
    │   ├── ProductSearch/ProductSearch.js
    │   ├── BillTable/BillTable.js
    │   └── InvoicePreview/InvoicePreview.js
    │
    ├── database/
    │   ├── products/products.js      ← Products data store (placeholder)
    │   ├── customers/customers.js    ← Customers data store (placeholder)
    │   └── bills/bills.js            ← Bills data store (placeholder)
    │
    ├── assets/
    │   ├── images/                   ← Image assets
    │   └── icons/                    ← Icon assets
    │
    └── utils/
        ├── router.js                 ← Hash-based client-side router
        └── helpers.js                ← Shared utility functions (placeholder)
```

## Running

Open `index.html` directly in a browser — no build step required.

## Status

🚧 **Scaffolding only.** All pages and database modules are empty placeholders.
No billing logic, database logic, or advanced styling has been implemented yet.
